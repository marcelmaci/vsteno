<?php
require_once "session.php";
$_SESSION['font_in_session'] = $_POST['font_as_text'];
?>
