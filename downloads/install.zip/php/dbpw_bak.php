<?php

// contains login and password for database
const db_servername = "127.0.0.1";
const db_username = "d281-_AX2fgu";
const db_password = "Nlz8Pqn3#?";
const db_dbname = "d281-53239_vsteno";

const master_pwhash = "ee79976c9380d5e337fc1c095ece8c8f22f91f306ceeb161fa51fecede2c4ba1";

// privileges
const normal_user = 1;          // can write to purgatorium
const super_user = 2;           // can write to elysium

// connects to database

function Connect2DB() {
    return new mysqli(db_servername, db_username, db_password, db_dbname);
}


function connect_or_die() {
        // Create connection
        $conn = Connect2DB();
        // Check connection
        if ($conn->connect_error) {
            die_more_elegantly("Verbindung nicht möglich: " . $conn->connect_error . "<br>");
        }
        return $conn;
}

?>