<?php session_start(); ?>
<!-- <!DOCTYPE HTML> -->
<html>
<head>
    <meta charset='utf-8'>
    <title>VSTENO - Vector Shorthand Tool with Enhanced Notational Options</title>
</head>
<body>