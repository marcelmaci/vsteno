<?php
require_once "vsteno_template_top.php";
?>
<h1>Oooops ...</h1>
<p>Tja, Technik ... der letzte Upload lief nicht wie geplant. VSTENO bekam einige neue Funktionen, sowie ein Modell für Spanisch, das bei mir lokal wunderbar läuft 
(aber auf dem Server nicht).</p>
<p>Ich werde versuchen, das Problem in den nächsten Tagen zu lösen (oder sonst auf die alte Version zurückzumigrieren). Sie können über <a href="introduction.php">diesen Link</a> probieren, 
ob es bereits funktioniert.</p>
<p>In der Zwischenzeit hier ein "Preview" auf das Spanische System (Stolze-Schrey): <a href="../docs/donquijote1.pdf">Beispiel</a></p>
<p>Stay hungry - stay foolish ;) mm</p>
<?php
require_once "vsteno_template_bottom.php";
?>