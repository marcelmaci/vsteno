<!-- DOCTYPE HTML -->
<html>
<head>
    <meta charset='utf-8'>
    <title>VSTENO - Vector Shorthand Tool with Enhanced Notational Options</title>
</head>
<body>
<?php
        $language = "fr";
        $alphabet_option = "-x"; // "--ipa"; 
        $word = "français";
        $shell_command = "espeak -q -v $language $alphabet_option \"$word\"";
        echo "$shell_command<br>";
        
        exec("$shell_command",$o);
        var_dump($o);
?>
</body>
</html> 
