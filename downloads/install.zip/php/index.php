<?php
 header("Location: https://www.vsteno.ch/php/ooops.php");
 exit;
?>