

<?php 
require "vsteno_template_top.php";
echo "<h1>test</h2>";
require "vsteno_template_bottom.php";
?>
  </body>
</html>

