<?php
require_once "session.php";

require_once "vsteno_template_top.php";
require_once "constants.php";

echo "<h1>Zeichen</h1>";
/*
echo $_SESSION['model_standard_or_custom'];
echo $_SESSION['user_privilege'];
*/

if (($_SESSION['model_standard_or_custom'] === 'standard') && ($_SESSION['user_privilege'] < 2)) {
    echo "<p>Sie arbeiten aktuell mit dem Model <b><i>standard</i></b>. Wenn Sie Ihr eigenes Stenografie-System bearbeiten wollen, ändern sie das Modell auf <b><i>custom</i></b> und rufen Sie diese Seite erneut auf.</p>";
    echo "<p><a href='toggle_model.php'><button>ändern</button></a></p>";
} else { 
        echo "<p>Hier können Sie die Zeichen (Font) Ihres eigenen Stenosystems editieren und speichern.</p><p><b>ACHTUNG:</b><br><i>Es wird KEINE Syntax-Prüfung vorgenommen. Falls die Definitionen
        Fehler aufweisen, werden Sie NICHT darauf hingewiesen! (Sorry guys ... technisch (noch nicht) möglich;-)</i></p>";
    
        // use javascript for textarea in order to prevent predefined function of tab to change focus (use it for indentation instead)

echo "<form action='edit_font.php' method='post'>
        <textarea id='font_as_text' name='font_as_text' rows='35' cols='120' spellcheck='false'  
        onkeydown=\"if(event.keyCode===9){var v=this.value,s=this.selectionStart,e=this.selectionEnd;this.value=v.substring(0, s)+'\t'+v.substring(e);this.selectionStart=this.selectionEnd=s+1;return false;}\"
        >" . htmlspecialchars($_SESSION['font_in_session']) . "</textarea><br>
        <input type='submit' name='action' value='speichern'>
        </form>";

}


require_once "vsteno_template_bottom.php";

?>
