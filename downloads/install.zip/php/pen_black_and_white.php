<?php require "vsteno_template_top.php"; ?>
<h1>Bildnachweis</h1>
<p>Autor und Rechteinhaber des Bildes "<a href="https://www.flickr.com/photos/kosheahan/8739090988">Fountain Pen</a>" ist 
<a href="https://www.flickr.com/people/kosheahan/">koshean</a>.</p>
<p>Das Werk steht unter der Attribution 2.0 Generic License 
(<a href="https://creativecommons.org/licenses/by/2.0/legalcode">CC BY 2.0</a>).</p>
<?php require "vsteno_template_bottom.php"; ?>