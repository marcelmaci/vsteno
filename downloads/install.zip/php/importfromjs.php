
<?php

header('Content-type: application/json');
$json = file_get_contents('php://input');

$json_decode = json_decode($json, true);

$getnme=$json_decode->{'name'};
$json_response = json_encode($json_decode);
echo $getnme;
echo $json

//require_once "dbpw.php";

/*
$sql= "UPDATE blabla SET model='".$getnme."' WHERE id=1";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully: $sql";
} 

*/


?>