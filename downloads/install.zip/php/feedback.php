<?php require "vsteno_template_top.php"; ?>
<h1>Fehler</h1>
<p>Hier können Sie Fehler im Programm - insbesondere falsch berechnete Stenogramme - melden.</p>
<p><i>... folgt.</i></p>
<?php require "vsteno_template_bottom.php"; ?>