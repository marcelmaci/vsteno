<?php

// contains login and password for database
const db_servername = "127.0.0.1";
const db_username = "root";
const db_password = "susmd442D442";
const db_dbname = "vstenodb";

const master_pwhash = "ee79976c9380d5e337fc1c095ece8c8f22f91f306ceeb161fa51fecede2c4ba1";

// privileges
const normal_user = 1;          // can write to purgatorium
const super_user = 2;           // can write to elysium

// connects to database

function Connect2DB() {
    return new mysqli(db_servername, db_username, db_password, db_dbname);
}

?>