<?php require "vsteno_template_top.php"; ?>
<h1>Webversion</h1>
<p><i>... folgt.</i></p>
<?php require "vsteno_template_bottom.php"; ?>