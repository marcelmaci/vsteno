#!/bin/bash
./install_tools.sh
./download_vsteno.sh
./configure_database.sh
